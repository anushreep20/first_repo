<footer>
    <center>
    <div class="row ">
        <div class="col-md-3 col-sm-6 home-feature">
            <p> Information</p>
            <a href="about.php">About Us</a><br>
            <a href="contact.php">Contact Us</a><br>
        </div>
    
        <div class="col-md-3 col-sm-6 home-feature">
            <p> My Account </p>
            <a href="login.php">Login</a><br>
            <a href="signup.php">Sign Up</a><br>
        </div>
     
        <div class="col-md-3 col-sm-6 home-feature">
            <p>Contact us </p> <p>Contact: +91-123-000000</p>
        </div>
    </div>
    </center>
</footer>