<!---<?php
$con = mysqli_connect("localhost", "root", "", "mobilestore","3308") or die($mysqli_error($con));
 if(!isset($_SESSION)) 
    { 
        session_start();
        unset($_SESSION["session"]);

    }
/*
if ($con->connect_error) {
  die("Connection failed: " . $con->connect_error);
}
echo "Connected successfully"; */
?>--->